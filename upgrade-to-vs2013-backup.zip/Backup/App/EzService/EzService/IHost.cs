﻿namespace EzService {

	public interface IHost {
		void Shutdown();
	} // interface IHost

} // namespace EzService
