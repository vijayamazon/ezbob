﻿using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("EzService")]
[assembly: AssemblyDescription("")]
[assembly: Guid("1640c131-cbbb-4e81-8dc0-9fb52e41d4f4")]
