using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyProduct("Ezbob WEB")]
[assembly: AssemblyCompany("Orange Money Ezbob Ltd")]
[assembly: AssemblyCopyright("Copyright (c) Orange Money Ezbob Ltd")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]