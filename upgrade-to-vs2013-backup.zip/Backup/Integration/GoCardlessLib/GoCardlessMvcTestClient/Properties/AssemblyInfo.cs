﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("GoCardlessMvcTestClient")]
[assembly: AssemblyDescription("")]
[assembly: Guid("4d1b5cd5-8cc8-44f6-8a94-0baf3f233b81")]
